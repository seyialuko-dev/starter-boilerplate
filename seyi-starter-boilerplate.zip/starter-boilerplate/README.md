
# Starter Boilerplate

A responsive HTML/CSS/JS boilerplate layout by Seyi Aluko.

## Includes:
- Header with navigation
- Hero section with CTA
- 3-column features section
- Responsive footer
- Mobile-first CSS with Flexbox

## How to Use:
1. Clone or download the project
2. Open `index.html` in your browser
3. Start customizing!
